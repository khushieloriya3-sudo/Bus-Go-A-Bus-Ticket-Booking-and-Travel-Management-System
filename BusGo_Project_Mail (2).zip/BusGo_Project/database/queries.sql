-- =====================================================================
--  Ready-to-use queries (phpMyAdmin > SQL tab). Run database.sql first.
-- =====================================================================
USE bus_system;

-- 1. SEARCH: buses between two cities on a date, with arrival time and seats left
SET @origin = 'Mumbai', @dest = 'Pune', @date = CURDATE() + INTERVAL 3 DAY;

SELECT sc.schedule_id, b.name AS bus_name, b.bus_type,
       sc.departure_time,
       ADDTIME(sc.departure_time, SEC_TO_TIME(sc.duration_minutes * 60)) AS arrival_time,
       sc.duration_minutes, sc.fare,
       b.total_seats - (
           SELECT COUNT(*)
           FROM booking_seats bs
           JOIN bookings bk ON bk.booking_id = bs.booking_id
           WHERE bs.schedule_id = sc.schedule_id
             AND bs.travel_date = @date
             AND bk.status IN ('pending','confirmed')
       ) AS seats_left
FROM schedules sc
JOIN routes r ON r.route_id = sc.route_id
JOIN stops os ON os.stop_id = r.origin_stop_id
JOIN stops ds ON ds.stop_id = r.destination_stop_id
JOIN buses  b ON b.bus_id   = sc.bus_id
WHERE os.city = @origin AND ds.city = @dest
  AND sc.status = 'active' AND b.status = 'active'
  AND FIND_IN_SET(DATE_FORMAT(@date, '%a'), sc.operating_days) > 0
ORDER BY sc.departure_time;

-- 2. The same list using the view
SELECT * FROM v_schedule_details WHERE origin = 'Mumbai' AND destination = 'Pune' ORDER BY departure_time;

-- 3. All cities for the search suggestions
SELECT DISTINCT city FROM stops ORDER BY city;

-- 4. Seat map for one trip: every seat of the bus and whether it is taken (schedule 1)
SELECT se.seat_number, se.seat_type,
       IF(bs.seat_id IS NULL, 'available', 'booked') AS state
FROM schedules sc
JOIN seats se ON se.bus_id = sc.bus_id
LEFT JOIN (SELECT bs.seat_id FROM booking_seats bs
           JOIN bookings bk ON bk.booking_id = bs.booking_id
           WHERE bs.schedule_id = 1 AND bs.travel_date = @date
             AND bk.status IN ('pending','confirmed')) bs ON bs.seat_id = se.seat_id
WHERE sc.schedule_id = 1
ORDER BY se.seat_number;

-- 5. MAKE A BOOKING (all or nothing). Change the values to try it.
START TRANSACTION;
  INSERT INTO bookings (booking_ref, user_id, schedule_id, travel_date, passenger_name, passenger_phone, seats_count, total_amount, status)
  VALUES ('BUS100099', 2, 6, @date, 'Asha Patil', '9000000002', 2, 900.00, 'pending');
  SET @bid = LAST_INSERT_ID();

  -- seat_id values come from the seats table (bus of schedule 6)
  INSERT INTO booking_seats (booking_id, schedule_id, seat_id, travel_date)
  SELECT @bid, 6, se.seat_id, @date
  FROM schedules sc JOIN seats se ON se.bus_id = sc.bus_id
  WHERE sc.schedule_id = 6 AND se.seat_number IN (7, 8);   -- a seat already taken makes this fail

  INSERT INTO payments (booking_id, amount, method, status, transaction_ref, paid_at)
  VALUES (@bid, 900.00, 'upi', 'success', 'UPI20269999999', NOW());

  UPDATE bookings SET status = 'confirmed' WHERE booking_id = @bid;
  INSERT INTO notifications (user_id, booking_id, type, title, message)
  VALUES (2, @bid, 'booking_confirmed', 'Booking confirmed', 'Your booking BUS100099 is confirmed.');
COMMIT;

-- 6. CANCEL A BOOKING: free the seats and mark the payment refunded
START TRANSACTION;
  UPDATE bookings SET status = 'cancelled' WHERE booking_ref = 'BUS100099';
  DELETE bs FROM booking_seats bs JOIN bookings bk ON bk.booking_id = bs.booking_id WHERE bk.booking_ref = 'BUS100099';
  UPDATE payments p JOIN bookings bk ON bk.booking_id = p.booking_id
     SET p.status = 'refunded' WHERE bk.booking_ref = 'BUS100099' AND p.status = 'success';
COMMIT;

-- 7. A user's bookings with trip details
SELECT bk.booking_ref, os.city AS origin, ds.city AS destination, bk.travel_date,
       sc.departure_time, bk.seats_count, bk.total_amount, bk.status
FROM bookings bk
JOIN schedules sc ON sc.schedule_id = bk.schedule_id
JOIN routes r ON r.route_id = sc.route_id
JOIN stops os ON os.stop_id = r.origin_stop_id
JOIN stops ds ON ds.stop_id = r.destination_stop_id
WHERE bk.user_id = 2
ORDER BY bk.travel_date DESC;

-- 8. Unread notifications of a user
SELECT title, message, created_at FROM notifications WHERE user_id = 2 AND is_read = 0 ORDER BY created_at DESC;

-- 9. Average rating per bus
SELECT b.name, ROUND(AVG(rv.rating), 1) AS avg_rating, COUNT(*) AS reviews
FROM reviews rv
JOIN bookings bk ON bk.booking_id = rv.booking_id
JOIN schedules sc ON sc.schedule_id = bk.schedule_id
JOIN buses b ON b.bus_id = sc.bus_id
GROUP BY b.bus_id, b.name ORDER BY avg_rating DESC;

-- 10. Revenue per route (successful payments only)
SELECT os.city AS origin, ds.city AS destination, SUM(p.amount) AS revenue
FROM payments p
JOIN bookings bk ON bk.booking_id = p.booking_id
JOIN schedules sc ON sc.schedule_id = bk.schedule_id
JOIN routes r ON r.route_id = sc.route_id
JOIN stops os ON os.stop_id = r.origin_stop_id
JOIN stops ds ON ds.stop_id = r.destination_stop_id
WHERE p.status = 'success'
GROUP BY r.route_id, os.city, ds.city ORDER BY revenue DESC;

-- 11. A driver's timetable
SELECT d.full_name, os.city AS origin, ds.city AS destination, sc.departure_time
FROM schedules sc
JOIN drivers d ON d.driver_id = sc.driver_id
JOIN routes r ON r.route_id = sc.route_id
JOIN stops os ON os.stop_id = r.origin_stop_id
JOIN stops ds ON ds.stop_id = r.destination_stop_id
WHERE d.driver_id = 1 ORDER BY sc.departure_time;

-- 12. MY BOOKINGS: upcoming (current) bookings of a user
SELECT bk.booking_ref, os.city AS origin, ds.city AS destination, bk.travel_date, sc.departure_time,
       bk.seats_count, bk.total_amount, bk.status
FROM bookings bk
JOIN schedules sc ON sc.schedule_id = bk.schedule_id
JOIN routes r ON r.route_id = sc.route_id
JOIN stops os ON os.stop_id = r.origin_stop_id
JOIN stops ds ON ds.stop_id = r.destination_stop_id
WHERE bk.user_id = 2 AND bk.status IN ('pending','confirmed') AND bk.travel_date >= CURDATE()
ORDER BY bk.travel_date, sc.departure_time;

-- 13. MY BOOKINGS: previous bookings of a user (completed, cancelled or already travelled)
SELECT bk.booking_ref, os.city AS origin, ds.city AS destination, bk.travel_date, sc.departure_time,
       bk.seats_count, bk.total_amount, bk.status
FROM bookings bk
JOIN schedules sc ON sc.schedule_id = bk.schedule_id
JOIN routes r ON r.route_id = sc.route_id
JOIN stops os ON os.stop_id = r.origin_stop_id
JOIN stops ds ON ds.stop_id = r.destination_stop_id
WHERE bk.user_id = 2 AND (bk.status IN ('completed','cancelled') OR bk.travel_date < CURDATE())
ORDER BY bk.travel_date DESC;

-- 14. WALLET: balance and transaction history of a user
SELECT w.balance FROM wallets w WHERE w.user_id = 2;
SELECT t.created_at, t.type, t.purpose, t.amount, t.balance_after, t.description
FROM wallet_transactions t JOIN wallets w ON w.wallet_id = t.wallet_id
WHERE w.user_id = 2 ORDER BY t.txn_id DESC;

-- 15. WALLET TOP-UP (one transaction: ledger row + new balance)
START TRANSACTION;
  SELECT balance INTO @bal FROM wallets WHERE user_id = 2 FOR UPDATE;
  UPDATE wallets SET balance = balance + 500 WHERE user_id = 2;
  INSERT INTO wallet_transactions (wallet_id, type, purpose, amount, balance_after, description)
  SELECT wallet_id, 'credit', 'topup', 500.00, balance, 'Added money' FROM wallets WHERE user_id = 2;
COMMIT;

-- 16. Check: every wallet balance equals the sum of its ledger rows (should return no rows)
SELECT w.wallet_id, w.balance,
       COALESCE(SUM(IF(t.type = 'credit', t.amount, -t.amount)), 0) AS ledger_total
FROM wallets w LEFT JOIN wallet_transactions t ON t.wallet_id = w.wallet_id
GROUP BY w.wallet_id, w.balance
HAVING w.balance <> ledger_total;
