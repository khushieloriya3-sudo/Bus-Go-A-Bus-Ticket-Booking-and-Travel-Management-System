<?php
// Default XAMPP credentials. Change if you set a MySQL password.
$DB = ['host' => 'localhost', 'name' => 'bus_system', 'user' => 'root', 'pass' => ''];
define('USER_ID', 2);   // demo: the signed-in passenger (a login screen is a later step)
