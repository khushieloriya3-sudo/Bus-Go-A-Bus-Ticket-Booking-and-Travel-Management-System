<?php
// Wallet + booking API. Every request is a POST: api.php?op=wallet|topup|pay|refund
require __DIR__ . '/config.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

class UserErr extends Exception {}
function out($a, $code = 200) { http_response_code($code); echo json_encode($a); exit; }
$in = json_decode(file_get_contents('php://input'), true) ?: [];
try {
    $pdo = new PDO("mysql:host={$DB['host']};dbname={$DB['name']};charset=utf8mb4", $DB['user'], $DB['pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
} catch (Exception $e) { out(['error' => 'Database connection failed. Is MySQL running and database.sql imported?'], 500); }

function wallet($pdo, $lock = false) {
    $s = $pdo->prepare('SELECT wallet_id, balance FROM wallets WHERE user_id = ?' . ($lock ? ' FOR UPDATE' : ''));
    $s->execute([USER_ID]); $w = $s->fetch();
    if (!$w) { $pdo->prepare('INSERT INTO wallets (user_id) VALUES (?)')->execute([USER_ID]); return wallet($pdo, $lock); }
    return $w;
}
// Adds one ledger row and updates the balance (call inside a transaction)
function ledger($pdo, $w, $type, $purpose, $amt, $desc, $bid = null) {
    $new = $w['balance'] + ($type === 'credit' ? $amt : -$amt);
    $pdo->prepare('UPDATE wallets SET balance = ? WHERE wallet_id = ?')->execute([$new, $w['wallet_id']]);
    $pdo->prepare('INSERT INTO wallet_transactions (wallet_id, type, purpose, amount, balance_after, booking_id, description) VALUES (?,?,?,?,?,?,?)')
        ->execute([$w['wallet_id'], $type, $purpose, $amt, $new, $bid, $desc]);
}
function state($pdo) {
    $w = wallet($pdo);
    $s = $pdo->prepare('SELECT type, amount, description AS `desc`, balance_after AS bal, UNIX_TIMESTAMP(created_at) * 1000 AS at
                        FROM wallet_transactions WHERE wallet_id = ? ORDER BY txn_id DESC LIMIT 30');
    $s->execute([$w['wallet_id']]); $rows = $s->fetchAll();
    foreach ($rows as &$r) { $r['amount'] = (float)$r['amount']; $r['bal'] = (float)$r['bal']; $r['at'] = (int)$r['at']; }
    return ['balance' => (float)$w['balance'], 'transactions' => $rows];
}

$op = $_GET['op'] ?? '';
try {
    if ($op === 'wallet') out(state($pdo));

    if ($op === 'topup') {
        $a = round((float)($in['amount'] ?? 0), 2);
        if ($a < 10 || $a > 50000) throw new UserErr('Enter an amount from 10 to 50,000.');
        $pdo->beginTransaction();
        ledger($pdo, wallet($pdo, true), 'credit', 'topup', $a, 'Added money');
        $pdo->commit(); out(state($pdo));
    }

    if ($op === 'pay') {                                   // book seats and pay from the wallet, all or nothing
        $sid = (int)($in['schedule_id'] ?? 0); $date = $in['date'] ?? '';
        $seats = array_values(array_unique(array_map('intval', $in['seats'] ?? [])));
        $name = trim($in['name'] ?? ''); $phone = $in['phone'] ?? '';
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || $date < date('Y-m-d')) throw new UserErr('Invalid travel date.');
        if (count($seats) < 1 || count($seats) > 6 || strlen($name) < 2 || !preg_match('/^\d{10}$/', $phone)) throw new UserErr('Check the passenger details and seats.');
        $s = $pdo->prepare("SELECT fare, bus_id FROM schedules WHERE schedule_id = ? AND status = 'active'");
        $s->execute([$sid]); $sc = $s->fetch();
        if (!$sc) throw new UserErr('Bus not found.');
        $amount = round($sc['fare'] * count($seats), 2);   // price is always taken from the database

        $pdo->beginTransaction();
        $w = wallet($pdo, true);
        if ($w['balance'] < $amount) throw new UserErr('Not enough wallet balance. Add money first.');
        $q = $pdo->prepare('SELECT seat_id FROM seats WHERE bus_id = ? AND seat_number IN (' . implode(',', array_fill(0, count($seats), '?')) . ')');
        $q->execute(array_merge([$sc['bus_id']], $seats)); $ids = $q->fetchAll(PDO::FETCH_COLUMN);
        if (count($ids) !== count($seats)) throw new UserErr('Invalid seat selected.');

        $ref = 'BUS' . random_int(100000, 999999);
        $pdo->prepare("INSERT INTO bookings (booking_ref, user_id, schedule_id, travel_date, passenger_name, passenger_phone, seats_count, total_amount, status)
                       VALUES (?,?,?,?,?,?,?,?, 'confirmed')")->execute([$ref, USER_ID, $sid, $date, $name, $phone, count($seats), $amount]);
        $bid = (int)$pdo->lastInsertId();
        $ins = $pdo->prepare('INSERT INTO booking_seats (booking_id, schedule_id, seat_id, travel_date) VALUES (?,?,?,?)');
        foreach ($ids as $id) $ins->execute([$bid, $sid, $id, $date]);   // UNIQUE key stops double booking
        $pdo->prepare("INSERT INTO payments (booking_id, amount, method, status, transaction_ref, paid_at) VALUES (?,?, 'wallet','success',?, NOW())")
            ->execute([$bid, $amount, 'WAL' . $ref . date('His')]);
        ledger($pdo, $w, 'debit', 'booking', $amount, 'Booking ' . $ref, $bid);
        $pdo->prepare("INSERT INTO notifications (user_id, booking_id, type, title, message) VALUES (?,?, 'booking_confirmed','Booking confirmed',?)")
            ->execute([USER_ID, $bid, "Your booking $ref is confirmed."]);
        $pdo->commit();
        $st = state($pdo); $st['booking_ref'] = $ref; out($st);
    }

    if ($op === 'refund') {                                // cancel a booking and return the money to the wallet
        $ref = $in['ref'] ?? '';
        $pdo->beginTransaction();
        $s = $pdo->prepare("SELECT booking_id, total_amount FROM bookings WHERE booking_ref = ? AND user_id = ? AND status IN ('pending','confirmed') FOR UPDATE");
        $s->execute([$ref, USER_ID]); $b = $s->fetch();
        if (!$b) throw new UserErr('Booking not found or already cancelled.');
        $pdo->prepare("UPDATE bookings SET status = 'cancelled' WHERE booking_id = ?")->execute([$b['booking_id']]);
        $pdo->prepare('DELETE FROM booking_seats WHERE booking_id = ?')->execute([$b['booking_id']]);
        $pdo->prepare("UPDATE payments SET status = 'refunded' WHERE booking_id = ? AND status = 'success'")->execute([$b['booking_id']]);
        ledger($pdo, wallet($pdo, true), 'credit', 'refund', (float)$b['total_amount'], 'Refund ' . $ref, $b['booking_id']);
        $pdo->commit(); out(state($pdo));
    }
    out(['error' => 'Unknown request'], 404);
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    if ($e instanceof UserErr) out(['error' => $e->getMessage()], 400);
    out(['error' => $e instanceof PDOException && $e->getCode() === '23000'
        ? 'One of those seats was just booked. Pick other seats.' : 'Something went wrong on the server.'], 500);
}
