# BusGo - Bus Booking System

```
BusGo_Project/
├── index.html            page (design and code are inside this one file)
├── api/api.php           PHP API (wallet + booking payment)
├── api/config.php        database login (XAMPP defaults)
└── database/
    ├── database.sql      all tables + sample data (import in phpMyAdmin)
    ├── queries.sql       ready-to-use SQL
    └── er_diagram.mermaid
```

## Option A: frontend only (fastest, wallet runs in offline demo mode)
1. VS Code > File > Open Folder > `BusGo_Project`.
2. Install the **Live Server** extension.
3. Right-click `index.html` > **Open with Live Server** (or just double-click `index.html`).

## Option B: full project with MySQL (XAMPP)
1. Copy the folder to `C:\xampp\htdocs\BusGo_Project`.
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Open http://localhost/phpmyadmin > **Import** > choose `database/database.sql` > Go.
4. Open http://localhost/BusGo_Project/ in Chrome.
5. Wallet > **Database server URL** > type `api/api.php` > Save. It now says "Online (MySQL database)".

If MySQL has a password, edit `api/config.php`.

## Open it on your phone (same Wi-Fi)
Find your computer's IP (`ipconfig`, e.g. 192.168.1.5) and open `http://192.168.1.5/BusGo_Project/` in Chrome. Use `api/api.php` as the server URL there too.

## Notes
- The demo user is `USER_ID` in `api/config.php` (login is a later step).
- Bus list, seat availability and "My bookings" are stored in the app/phone. The wallet and booking payment use MySQL.
